﻿using Fungus;
using GUIPackage;
using JSONClass;
using KBEngine;
using PaiMai;
using SkySwordKill.Next.DialogEvent;
using SkySwordKill.Next.DialogSystem;
using SkySwordKill.NextMoreCommand.Attribute;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YueNing.MoDaoYaoNv
{
    [DialogEvent("SuoQu")]
    [DialogEvent("索取")]
    public class SuoQu : IDialogEvent
    {
        private string mingCheng;
        private int shuLiang;
        public static string PinJie1 = "柴刀";

        public void Execute(DialogCommand command, DialogEnvironment env, Action callback)
        {
            mingCheng = command.GetStr(0);
            shuLiang = command.GetInt(1, 0);

            var time = PlayerEx.Player.worldTimeMag;
            var needItem = NeedItem(mingCheng);

            if (needItem != null)
            {
                var quality = needItem.quality;
                var shuLiangPrices = needItem.price * shuLiang;
                var lastTime = new DateTime(1, 1, 1);
                var needTime =
                    new TimeSpan((int)(Math.Sqrt(shuLiangPrices / 300 * (0.8 + quality / 5))), 0, 0,
                        0);

                if (DialogAnalysis.GetStr("lastTime").Length != 0)
                {
                    lastTime = Convert.ToDateTime(DialogAnalysis.GetStr("lastTime"));
                }

                var nowTime = time.getNowTime();
                var resultTime = lastTime + needTime;
                if (resultTime > nowTime)
                {
                    var timeSpan = resultTime - nowTime;
                    DialogAnalysis.SetStr("wait", "Yes");
                    var needYear = timeSpan.Days / 365;
                    var needMonth = timeSpan.Days % 12;
                    var needDay = timeSpan.Days % 365;
                    DialogAnalysis.SetStr("needYear", needYear.ToString());
                    DialogAnalysis.SetStr("needMonth", needMonth.ToString());
                    DialogAnalysis.SetStr("needDay", needDay.ToString());
                }
                else
                {
                    var needQingFen = shuLiangPrices * 2;
                    var qingFen = NPCEx.GetQingFen(7200);
                    DialogAnalysis.SetStr("wait", "No");
                    if ((qingFen >= needQingFen && quality <= 5)
                        || (qingFen >= needQingFen * 10 && quality == 6))
                    {
                        UIPopTip.Inst.PopAddItem(needItem.name,shuLiang);
                       // UIPopTip.Inst.Pop(string.Format("获得{0}*{1}", needItem.name, shuLiang), PopTipIconType.叹号);
                        PlayerEx.Player.addItem(needItem.id, shuLiang, null);
                        NPCEx.AddQingFen(7200, quality == 6 ? -needQingFen * 10 : -needQingFen);


                        DialogAnalysis.SetStr("lastTime", nowTime.ToString("yyyy-MM-dd"));
                    }
                    else
                    {
                        UIPopTip.Inst.Pop("当前情分不足", PopTipIconType.叹号);
                    }
                }
            }

            callback?.Invoke();
        }

        private List<int> _specialType = new List<int> { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
        private List<int> _goalType = new List<int> { 5, 6, 9 };

        public _ItemJsonData NeedItem(string mingCheng, List<int> specialType = null)
        {
            specialType = specialType ?? _specialType;
            var needItem =
                _ItemJsonData.DataList.First(item => specialType.Contains(item.type) && item.name == mingCheng);
            var flag = _goalType.Contains(needItem.type);
            if (!flag)
            {
                DialogAnalysis.SetStr("goal", "False");
                return null;
            }

            DialogAnalysis.SetStr("goal", "True");
            return needItem;
        }
    }
}