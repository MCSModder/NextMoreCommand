﻿using HarmonyLib;
using KBEngine;

using SkySwordKill.Next.DialogSystem;
using SkySwordKill.NextMoreCommand.Utils;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using UltimateSurvival;

namespace YueNing.MoDaoYaoNv
{
    [HarmonyPatch(typeof(Avatar), "AddTime")]
    public class JianCe
    {
        public static int npcID = 7200;
        public static bool IsDaoLv(int ID) => PlayerEx.IsDaoLv(NPCEx.NPCIDToNew(ID));
        public static List<bool> boolList = new List<bool>();
        public static void Postfix()
        {
            var isDaoLv = IsDaoLv(npcID);
            var flag1 = Check.onEnter();
            var flag2 = DialogAnalysis.GetInt("chuGuiCiShu") > 3;
            var flag3 = PlayerEx.Player.shouYuan - PlayerEx.Player.age <= 10 && isDaoLv ;
            var flag4 = ChuanYin_DongFu.onEnter();
            var flag5 = ChuanYin_HaiShang.onEnter();
            var flag6 = ChuanYin_BaiDiLou.onEnter();
            var flag7 = Check.Start();

            if (flag7)
            {
                ChuLi.onEnter();
            }
            if (flag1)
            {
                ChuLi.Start();
                ZhiXing.onEnter();
                if (isDaoLv && flag2)
                {
                    ChuLi.onEnter();
                }
            }
            if (flag3)
            {
                DialogAnalysis.SetInt("shouMing",1);
            }

            if (flag4)
            {
                DialogAnalysis.SwitchDialogEvent("妖女-传音-洞府传音");
            }
            else if (flag5)
            {
                DialogAnalysis.SwitchDialogEvent("妖女-传音-海上传音");
            }
            else if (flag6)
            {
                DialogAnalysis.SwitchDialogEvent("妖女-传音-白帝楼传音");
            }
        }


        //public static bool Check()
        //{
        //    var count = DaolvUtils.DaolvId.Count;
        //    var isDaoLv = IsDaoLv;
        //    var flag1 = isDaoLv && count > 1;
        //    var flag2 = !isDaoLv && count >= 1;
        //    return flag1 || ( HasInt("daHun") && flag2);
        //}


    }
}
