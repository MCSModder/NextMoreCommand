﻿using HarmonyLib;
using SkySwordKill.NextMoreCommand.Utils;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YueNing.MoDaoYaoNv
{
    public static class BiaoBai
    {
        public static string PinJie1 = "出轨";

        [HarmonyPostfix]
        [HarmonyPatch(typeof(GlobalValue), "Get")]
        public static void Test(ref int __result, string source)
        {
            StackTrace stackTrace = new StackTrace();
            string a = stackTrace.GetFrame(2).GetMethod().ToString();
            bool flag = source == "BiaoBaiManager.CalcBiaoBaiScore 获取道侣数量" &&
                        a == "Void DMD<BiaoBaiManager::CalcBiaoBaiScore>()";
            if (flag)
            {
                if (UINPCJiaoHu.Inst.NowJiaoHuNPC.ID == NPCEx.NPCIDToNew(7200))
                {
                    var tianfu = Tools.instance.CheckHasTianFu(24001);
                    var shenShi = Check.HasInt("shenShi");
                    if (Check.HasInt("huaXin") || DaolvUtils.DaolvId.Count > 1)
                    {
                        __result += 200;
                    }
                    else if (shenShi && tianfu)
                    {
                        __result -= 200;
                    }
                    else if (shenShi || tianfu)
                    {
                        __result -= 30;
                    }
                }
            }
        }
    }
}