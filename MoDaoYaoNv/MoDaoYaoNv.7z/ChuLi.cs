﻿using SkySwordKill.Next.DialogSystem;
using SkySwordKill.NextMoreCommand.Utils;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YueNing.MoDaoYaoNv
{
    internal static class ChuLi
    {
        public static void onEnter()
        {
            DaolvUtils.SetAllDaolvDeath(7200);
        }

        public static void Start()
        {
            DialogAnalysis.SetInt("chuGuiCiShu", DialogAnalysis.GetInt("chuGuiCiShu") + 1);
        }
    }
}
