﻿using SkySwordKill.Next.DialogSystem;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YueNing.MoDaoYaoNv
{
    internal static class ZhiXing
    {
        public static void SwitchDialogEvent(string pinJie)=>DialogAnalysis.SwitchDialogEvent(string.Format("{0}-{1}-{2}{3}", Check.PinJie1, SuoQu.PinJie1, BiaoBai.PinJie1,pinJie));
        public static void onEnter()
        {
            switch (DialogAnalysis.GetInt("chuGuiCiShu"))
            {
                case 1:
                   SwitchDialogEvent(ChuanYin_DongFu.PinJie1);
                    break;
                case 2:
                   SwitchDialogEvent( ChuanYin_HaiShang.PinJie1);
                    break;
                case 3:
                    SwitchDialogEvent(ChuanYin_BaiDiLou.PinJie1);
                    break;
                default:
                    break;
            }
        }
    }
}
