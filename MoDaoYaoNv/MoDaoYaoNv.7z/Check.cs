﻿using SkySwordKill.Next.DialogSystem;
using SkySwordKill.NextMoreCommand.Utils;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YueNing.MoDaoYaoNv
{
    internal static class Check
    {
        public static string PinJie1 = "妖女";
        public static bool HasInt(string name) => DialogAnalysis.GetInt(name) == 1;
        public static bool IsDaoLv(int ID) => PlayerEx.IsDaoLv(NPCEx.NPCIDToNew(ID));
        public static bool onEnter()
        {
            var count = DaolvUtils.DaolvId.Count;
            var isDaoLv = IsDaoLv(7200);
            var flag1 = isDaoLv && count > 1;
            return flag1;
        }

        public static bool Start()
        {
            var count = DaolvUtils.DaolvId.Count;
            var isDaoLv = IsDaoLv(7200);
            var flag2 = !isDaoLv && count >= 1;
            return (HasInt("daHun") && flag2);
        }


    }

}
